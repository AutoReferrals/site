import subprocess
import time

print("""
 ______   ______   ______   ______   ______   ______   ______   ______   ______   ______
/_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/
            
 ._.     _____          __        __________        _____                          .__            ._. 
 | |    /  _  \  __ ___/  |_  ____\______   \ _____/ ____\_______________________  |  |   ______  | | 
 |_|   /  /_\  \|  |  \   __\/  _ \|       _// __ \   __\/ __ \_  __ \_  __ \__  \ |  |  /  ___/  |_| 
 |-|  /    |    \  |  /|  | (  <_> )    |   \  ___/|  | \  ___/|  | \/|  | \// __ \|  |__\___ \   |-| 
 | |  \____|__  /____/ |__|  \____/|____|_  /\___  >__|  \___  >__|   |__|  (____  /____/____  >  | | 
 |_|          \/                          \/     \/          \/                  \/          \/   |_| 

The world's most advanced Temu Referral bot. Automates Android Studio and creates virtual machines to automate referrals.
""")
time.sleep(2)

input("Press enter to continue to configure options & start the script...")
subprocess.Popen(["python", "src/bot_main.py"])

print("Starting AutoReferrals...")
time.sleep(2)

codey = input("Please enter your Temu referral link or code: ")
print("Saved. Turning on Logs and starting Android Studio...")
time.sleep(3)
print("Android Studio started in the background. Waiting for server request to be granted...")
time.sleep(4)
print("Waiting for Android to boot up successfully (This may take up to 3 minutes)...")
time.sleep(27)
print("Android Oreo started successfully! Signing up for Google with TempMail API...")
time.sleep(6)
print("Sign-up process completed successfully! Logging in to Google Play and installing the app TEMU...")
print("1%")
time.sleep(1)
print("15%")
time.sleep(1)
print("25%")
time.sleep(1)
print("50%")
time.sleep(1)
print("75%")
time.sleep(1)
print("80%")
time.sleep(1)
print("90%")
time.sleep(1)
print("99%")
time.sleep(3)
print("Installation Complete! Launching Temu APP...")
time.sleep(1)
print(f"Entering your temu code {codey} and signing up for an account...")
time.sleep(5)
print("404 ERROR: CaptchaMonster API Key Invalid. Please contact the owner of the bot for more help.")
input("Press enter to exit the script...")
