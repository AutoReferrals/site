ENTER FULLSCREEN TO GET THE FULL EXPERIENCE OF THESE INSTRUCTIONS      
If the script asks you for administrator priveliges, IT IS NOT LEGIT SOFTWARE. UNINSTALL RIGHT AWAY.                                                                                                
                                                                                                      
     ______   ______   ______   ______   ______   ______   ______   ______   ______   ______          
    /_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/          
                                                                                                      
                                                                                                      
 ._.     _____          __        __________        _____                          .__            ._. 
 | |    /  _  \  __ ___/  |_  ____\______   \ _____/ ____\_______________________  |  |   ______  | | 
 |_|   /  /_\  \|  |  \   __\/  _ \|       _// __ \   __\/ __ \_  __ \_  __ \__  \ |  |  /  ___/  |_| 
 |-|  /    |    \  |  /|  | (  <_> )    |   \  ___/|  | \  ___/|  | \/|  | \// __ \|  |__\___ \   |-| 
 | |  \____|__  /____/ |__|  \____/|____|_  /\___  >__|  \___  >__|   |__|  (____  /____/____  >  | | 
 |_|          \/                          \/     \/          \/                  \/          \/   |_| 
                                                                                                      
                                                                                                      
     ______   ______   ______   ______   ______   ______   ______   ______   ______   ______          
    /_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/  /_____/          
                                                                                                      
                                                                                                      

This is an text guide on how to get started on botting Temu with our flagship AutoReferrals tool.

---------------------------------------------

STEP ONE

You need to install the required dependencies and apps needed for AutoReferrals to function.
The only thing you, the user need to install is Android Studio. All pip modules will later on be installed by the .bat files.
Android Studio - https://developer.android.com/studio

---------------------------------------------

STEP TWO

Double click the BAT files in order - 
First execute install_python.bat which will install the correct python version for you. 
After that, execute install.bat which will install the required pip modules for you.
Finally, you can start up start.bat and the script will run without problems!

---------------------------------------------

IF STEP TWO DOES NOT WORK

Move the AutoReferrals folder to your Desktop.
Open the app "Command Prompt" on your computer. Admin access is NOT required. If the script asks you for administrator priveliges, IT IS NOT LEGIT SOFTWARE. UNINSTALL RIGHT AWAY.
Now, in the Command Prompt, type in "cd Desktop" and press enter
Nothing will happen, and a new line will appear. Type in "cd AutoReferrals" and press enter.
Then, go to your Desktop and run "install_python" and after that run "install". After those two scripts finish running, yuou can finally launcher AutoReferrals.
Now go back to the Command Prompt application and run "python3 AutoReferrals.py"
Then a Menu should appear, asking for your Temu Referral link or code. Enter your Temu Code (or link) and the new users should start coming in!

---------------------------------------------

DISCLAIMER

Enjoy! Please be aware that this script is intended solely for educational and legitimate purposes. I want to emphasize that I do not endorse or support any malicious activities. You, as the user, are solely responsible for the consequences of executing AutoReferrals.

Please exercise caution and restraint when using this script. Overuse or misuse of this bot can raise suspicions with Temu, potentially resulting in the suspension or termination of your account, or even worse like sending the FBI to your house. It's essential to use this tool responsibly and within the bounds of Temu's terms of service.

---------------------------------------------

MADE IN 2023 BY AutoReferrals, INC. PERMISSION GRANTED TO COPY AND SHARE FOR EDUCATIONAL PURPOSES. PERMISSION GRANTED TO MODIFY CODE AND DISTRIBUTE.
